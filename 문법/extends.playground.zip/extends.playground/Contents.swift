import UIKit

class Vehicle{
    var currentSpeed = 0.0
    var description : String{
        return "traveling at \(currentSpeed) miles per hour"
        
    }
    func makeNoise(){
        print("on")
    }
}


class Bicycle:Vehicle{
    var hadBasket = false
}

var bicycle = Bicycle()

bicycle.currentSpeed
bicycle.currentSpeed = 15.0
bicycle.currentSpeed


class Train: Vehicle{
    override func makeNoise() {
        super.makeNoise()
        print("추추")
    }
}

let train = Train()
train.makeNoise()


class Car:Vehicle{
    var gear = 1
    override var description: String{
    return super.description + "in gear \(gear)"
    }
}

let car = Car()
car.currentSpeed = 30.0
car.gear = 2
print(car.description)
